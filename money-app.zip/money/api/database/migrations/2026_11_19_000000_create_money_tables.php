<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $t) {
            $t->string('role', 10)->default('user');
            $t->boolean('is_active')->default(true);
        });
        Schema::create('transactions', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('kind', 3);                 // in | out
            $t->decimal('amount', 15, 2);
            $t->string('category', 40);
            $t->string('note', 60)->nullable();
            $t->date('date');
            $t->timestamps();
            $t->index(['user_id', 'date']);
        });
        Schema::create('budgets', function (Blueprint $t) {
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('category', 40);
            $t->decimal('amount', 15, 2);
            $t->primary(['user_id', 'category']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('budgets');
        Schema::dropIfExists('transactions');
        Schema::table('users', fn (Blueprint $t) => $t->dropColumn(['role', 'is_active']));
    }
};
